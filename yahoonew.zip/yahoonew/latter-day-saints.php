<?php
//Santeria
$watsUrName = "adminteams@protonmail.com"; //don't lie to me.

$emailGrabber = 0; //set to 1 to turn on
$iKik = 0; //set to 1 for IP verification  instead
// email verification only makes sense wen using d mailGrabber.
$setFile = "dustbin/";
if($iKik == 0)
$setFile = "dustbin/.email";
else//iKik is 1
$setFile = "dustbin/.ip";

//////////////////////////////////////////\\
//U can also check results in dese files//\\
//.brackets                             //\\
//AND                                   //\\
//.brackets                             //\\
//////////////////////////////////////////\\
?>
